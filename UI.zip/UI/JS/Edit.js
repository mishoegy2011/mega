let editor;
let coddde;
let textarea1;

window.onload = function () {
  editor = ace.edit("editor");
  editor.setTheme("ace/theme/cobalt");
  editor.session.setMode("ace/mode/php");
};

function changelang() {
  let language = $("#languages").val();
  if (language == "python") editor.session.setMode("ace/mode/python");
  else if (language == "java") editor.session.setMode("ace/mode/java");
  else if(language == 'cpp') editor.session.setMode("ace/mode/c_cpp");
  else if(language == 'node') editor.session.setMode("ace/mode/javascript");
}

function executeCode() {
  $.ajax({
    url: "/IDE/app/compiler.php",
    method: "POST",
    data: {
      language: $("#languages").val(),
      code: editor.getSession().getValue(),
    },
    success: function (response) {
      coddde = response;
      output.innerHTML = response;
    },
  });
 textarea1 = editor.getSession().getValue();
}