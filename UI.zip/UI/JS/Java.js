let editor;
let coddde;
let textarea1;

window.onload = function () {
  editor = ace.edit("editor");
  editor.setTheme("ace/theme/cobalt");
  editor.session.setMode("ace/mode/java");
};

function changelang() {
  let language = $("#languages").val();
  if (language == "python") editor.session.setMode("ace/mode/python");
  else if (language == "php") editor.session.setMode("ace/mode/php");
  else if(language == 'cpp') editor.session.setMode("ace/mode/c_cpp");
}

function executeCode() {
  $.ajax({
    url: "/IDE/app/compiler.php",
    method: "POST",
    data: {
      language: $("#languages").val(),
      code: editor.getSession().getValue(),
    },
    success: function (response) {
      coddde = response;
      output.innerHTML = response;
      
    },
  });
 textarea1 = editor.getSession().getValue();
  
}

// Save As 
const textarea = document.querySelector("textarea"),
fileNameInput = document.querySelector(".file-name input"),
selectMenu = document.querySelector(".save-as select"),
saveBtn = document.querySelector(".save-btn");

selectMenu.addEventListener("change", () => {
    const selectedFormat = selectMenu.options[selectMenu.selectedIndex].text;

    if(selectedFormat == "Choose extension") { 
      saveBtn.innerText = `Save As `;
    } else { 
      saveBtn.innerText = `Save As ${selectedFormat.split(" ")[0]} File`;}
});

saveBtn.addEventListener("click", () => {
    const blob = new Blob([textarea1]);
    const fileUrl = URL.createObjectURL(blob);
    const link = document.createElement("a");
    const Extension = selectMenu.options[selectMenu.selectedIndex].text;

    if(Extension == "PHP File (.php)"){
      let ex = ".php";
      link.download = fileNameInput.value.concat(ex);
    }
    else if(Extension == "Python File (.py)"){
      let ex = ".py";
      link.download = fileNameInput.value.concat(ex);
    }
    else if(Extension == "Java File (.java)"){
      let ex = ".java";
      link.download = fileNameInput.value.concat(ex);
    }
    else if(Extension == "cpp File (.cpp)"){
      let ex = ".cpp";
      link.download = fileNameInput.value.concat(ex);
    }
    else{link.download = fileNameInput.value; }

    link.href = fileUrl;
    link.click();
});

// Upload
function readSingleFile(e) {
  var file = e.target.files[0];
  if (!file) {
    return;
  }
  var reader = new FileReader();
  reader.onload = function(e) {
    var contents = e.target.result;
    displayContents(contents);
  };
  reader.readAsText(file);
}

function displayContents(contents) {
  editor.setValue(contents);
}

document.getElementById('file-input')
  .addEventListener('change', readSingleFile, false);