<?php require_once "controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
$password = $_SESSION['password'];
if($email != false && $password != false){
    $sql = "SELECT * FROM usertable WHERE email = '$email'";
    $run_Sql = mysqli_query($con, $sql);
    if($run_Sql){
        $fetch_info = mysqli_fetch_assoc($run_Sql);
        $status = $fetch_info['status'];
        $code = $fetch_info['code'];
        if($status == "verified"){
            if($code != 0){
                header('Location: reset-code.php');
            }
        }else{
            header('Location: user-otp.php');
        }
    }
}else{
    header('Location: Login.php');
}
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="description" content="Contact US through our website.">
    <meta name="keywords" content="Contact US MEGA IDE, MEGA IDE Contact US, MEGA Compiler Contact US, Contact US MEGA compiler.">
    <meta name="author" content="MEGA IDE">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/Contact US.css">
    <link rel="stylesheet" href="css/Responsive Contact Us.css">
    <link rel="stylesheet" href="css/Mobile Bar.css">
    <link rel="stylesheet" href="css/Responsive Mobile Bar.css">
    <link rel="stylesheet" href="css/Sidebar Menu.css">
    <link rel="stylesheet" href="css/Responsive Sidebar Menu.css">
    <link rel="shortcut icon" href="asset/icon/logo.png">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <!-- Font Awesome CDN Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
     <!-- AOS Animation Link -->
     <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <title>MEGA IDE | Contact US</title>
</head>
<style>
    body{
        background: url(asset/images/background\ 3.jpg);
        background-attachment: fixed;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
    }
    #preloader{
        background: rgba(0, 50, 64) url('asset/images/loading.gif') no-repeat center ;
        background-size: 50%;
        height: 100vh;
        width: 100%;
        position: fixed;
        z-index: 100;
    }
</style>
<body>
<div id="preloader"></div>
<!-- Small Bar (Small Screen)-->
<input type="checkbox" id="click" class="input10">
<div class="navigation" data-aos="zoom-out">
    <a href="Logout.php">
      <img src="asset/icon/home.png" alt="This is Home Logo">
    </a>
    <a href="Delete Files.php">
      <img src="asset/icon/layers.png" style="width: 30px; height: 30px;margin-top: 10px;" alt="This is Projects Logo">
    </a>
    <a href="Html & Css & js Compiler.php">
        <img src="asset/icon/code.png" alt="This is Html & Css & JS Logo">
    </a>
    <a href="Java Compiler.php">
      <img src="asset/icon/java.png" alt="This is Java Logo">
    </a>
    <a href="C++ Compiler.php">
      <img src="asset/icon/c plus plus.png" alt="This is C++ Logo">
    </a>
    <a href="PHP Compiler.php">
      <img src="asset/icon/php.png" alt="This is php Logo">
    </a>
    <a href="Python Compiler.php">
      <img src="asset/icon/python.png" alt="This is Python Logo">
    </a>
    <a href="Contact US.php">
      <img src="asset/icon/send.png" alt="This is Contact Logo">
    </a>
    <a href="Logout-User.php" onclick="window.alert('Signing out');">
      <i class='bx bx-log-out' style="color: #00BFA6;font-size: 25px;margin-left: -5px;margin-top: 13px;" id="log_in"></i>
    </a>
    <label class="fas fa-plus" for="click"></label>
</div>
<!-- Large Bar (Large Screen) -->
<div class="sidebar">
    <div class="logo-details">
      <div class="icon">
        <img src="asset/icon/logo.png" alt="" width="80" height="60">
      </div>
      <div class="logo_name">MEGA&nbsp;IDE</div>
      <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
        <li>
            <a href="Logout.php">
              <img src="asset/icon/home.png" alt="This is Home Logo" style="margin-left: 8px;">
              <span class="links_name">Home</span>
            </a>
            <span class="tooltip">Home</span>
        </li>
        <li>
          <a href="Delete Files.php">
            <img src="asset/icon/layers.png" alt="This is Projects Logo" style="margin-left: 8px;scale: 0.8;">
            <span class="links_name">My Projects</span>
          </a>
          <span class="tooltip">My Projects</span>
        </li>
        <li>
            <a href="Html & Css & js Compiler.php">
              <img src="asset/icon/code.png" alt="This is Html & Css & JS Logo" style="margin-left: 8px;">
              <span class="links_name">Html / Css / Js Editor</span>
            </a>
            <span class="tooltip">Html / Css / Js Editor</span>
        </li>
        <li>
            <a href="Java Compiler.php">
              <img src="asset/icon/java.png" alt="This is Java Logo" style="margin-left: 8px;">
              <span class="links_name">Online Java Compiler</span>
            </a>
            <span class="tooltip">Online Java Compiler</span>
        </li>
        <li>
            <a href="C++ Compiler.php">
              <img src="asset/icon/c plus plus.png" alt="This is C++ Logo" style="margin-left: 8px;">
              <span class="links_name">Online C & C++ Compiler</span>
            </a>
            <span class="tooltip">Online C & C++ Compiler</span>
        </li>
        <li>
            <a href="PHP Compiler.php">
              <img src="asset/icon/php.png" alt="This is php Logo" style="margin-left: 8px;">
              <span class="links_name">Online PHP Compiler</span>
            </a>
            <span class="tooltip">Online PHP Compiler</span>
        </li>
        <li>
            <a href="Python Compiler.php">
              <img src="asset/icon/python.png" alt="This is Python Logo" style="margin-left: 8px;">
              <span class="links_name">Online Python Compiler</span>
            </a>
            <span class="tooltip">Online Python Compiler</span>
        </li>
        <li>
            <a href="Contact US.php">
              <img src="asset/icon/send.png" alt="This is Contact Logo" style="margin-left: 8px;">
              <span class="links_name">Contact US</span>
            </a>
            <span class="tooltip">Contact US</span>
        </li>
        <br><br><br><br>
        <li class="profile">
            <div class="profile-details">
                <i class='bx bx-user-circle' style='color:#ffffff;'></i>
                <div class="name_job">
                    <div class="name">MEGA IDE</div>
                <div class="job">Compiler Code</div>
                </div>
            </div>
               <a href="Logout-User.php" onclick="window.alert('Signing out');"><i class='bx bx-log-out' style="color: #ffffff;" id="log_in"></i></a>
        </li>
    </ul>
</div>
<!-- Logo appear with Small Screen-->
<div class="logo5"
    data-aos="fade-right"
    data-aos-offset="500"
    data-aos-easing="ease-in-sine">
    <img src="asset/icon/logo.png" alt="" id="logo-img">
</div>
<!-- Contact Page -->
<div class="contact"
     data-aos="fade-down"
     data-aos-duration="3000">
    <div class="map" id="map">
      <iframe id="iframe" style="border:0;border-top-left-radius: 25px;border-bottom-left-radius: 25px;" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.openstreetmap.org/export/embed.html?bbox=30.283813476562504%2C29.672542219068987%2C31.816406250000004%2C30.3953840074964&amp;layer=mapnik"></iframe>
    </div>
    <div class="form">
        <h1>Contact US</h1>
        <form action="Opinion.php" method="post">
            <input type="text" name="name" placeholder="Enter Your Name ?" required minlength="10" id="name">
            <input type="email" name="email" placeholder="Enter Your Email ?" required id="email">
            <input type="tel" name="number" placeholder="Enter Your Number ?" minlength="11">
            <textarea placeholder="Please Enter Your Message ?" name="message" required minlength="30" id="message"></textarea>
            <center>
                <button type="submit" name="submit" onclick="myclick();">Send</button>
            </center>
        </form>
    </div>
</div>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="javascript/Sidebar Menu.js"></script>
<script src="javascript/Contact US.js"></script>
<Script src="javascript/Preloader.js"></Script>
<script>
  AOS.init();
</script>
</body>
</html>