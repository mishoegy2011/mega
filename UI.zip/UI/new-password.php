<?php require_once "controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
if($email == false){
  header('Location: login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MEGA IDE | New-Password</title>
    <link rel="stylesheet" href="css/Login & Registration Form.css">
    <link rel="stylesheet" href="css/Forgot Password.css">  
    <link rel="shortcut icon" href="asset/icon/logo.png">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <!-- Font Awesome CDN Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <!-- AOS Animation Link -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
      body{
        background: url(asset/images/background\ 3.jpg);
        background-attachment: fixed;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
      }
      #preloader{
        background: rgba(0, 50, 64) url('asset/images/loading.gif') no-repeat center ;
        background-size: 50%;
        height: 100vh;
        width: 100%;
        position: fixed;
        z-index: 100;
      }
    </style>
</head>
<body>
    <div id="preloader"></div>
    <!-- Logo appear with Small Screen-->
    <div class="logo5" 
        data-aos="fade-right"
        data-aos-offset="500"
        data-aos-easing="ease-in-sine">
        <img src="asset/icon/logo.png" alt="" id="logo-img">
    </div>
    <!-- New Password Page-->
    <div class="container"
     data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1500">
        <form action="new-password.php" method="POST" autocomplete="off">
            <h2 style="color: #fff; padding-bottom:10px; text-align:center;font-size:25px">New Password</h2>
            <?php 
                if(isset($_SESSION['info'])){
            ?>
            <div class="alert alert-success text-center" style="text-align:center;padding:7px;color:#155724;;background-color: #d4edda; margin-bottom:10px;border-radius:5px;">
                <?php echo $_SESSION['info']; ?>
            </div>
            <?php
                }
            ?>
            <?php
                if(count($errors) > 0){
            ?>
            <div class="alert alert-danger text-center" style="text-align:center;padding:7px;color:#a51b0b;background-color: #d4edda; margin-bottom:10px;border-radius:5px;">
                <?php   
                    foreach($errors as $showerror){
                        echo $showerror;
                    }
                ?>
            </div>
            <?php
                }
            ?>
            <div class="form-group">
                <input type="password" name="password" placeholder="Create New Password ?" required id="pass4" class="active4" minlength="6">
                <i id="icon4" class="fa fa-eye-slash"></i>
            </div>
            <div class="form-group">
                <input  style="margin-top: -10px;" type="password" name="cpassword" placeholder="Confirm Your Password ?" minlength="6" required id="pass5" class="active5">
                <i id="icon5" class="fa fa-eye-slash"></i>
            </div>
            <div class="form-group">
                <input style="margin-top: -10px;" class="form-control button" type="submit" name="change-password" value="Change">
            </div>
        </form>
    </div>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="javascript/Login & Registration Form.js"></script>
<Script src="javascript/Preloader.js"></Script>
<script>
    var e = document.getElementById('pass4');
    var f = document.getElementById('icon4');
    var h = document.getElementById('pass5');
    var i = document.getElementById('icon5');
    f.onclick = function(){
        if(e.className == 'active4'){
            e.setAttribute('type' , 'text');
            icon4.className = "fa fa-eye";
            e.className='';}
        else{
            e.setAttribute('type' , 'password');
            icon4.className = "fa fa-eye-slash";
            e.className='active4';
        }
    }

    i.onclick = function(){
        if(h.className == 'active5'){
            h.setAttribute('type' , 'text');
            icon5.className = "fa fa-eye";
            h.className='';}
        else{
            h.setAttribute('type' , 'password');
            icon5.className = "fa fa-eye-slash";
            h.className='active5';
        }
    }
    AOS.init();
</script>
</body>
</html>