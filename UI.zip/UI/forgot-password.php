<?php require_once "controllerUserData.php"; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MEGA IDE | Forgot-Password</title>
    <link rel="stylesheet" href="css/Login & Registration Form.css">
    <link rel="stylesheet" href="css/Forgot Password.css">
    <link rel="shortcut icon" href="asset/icon/logo.png">
    <!-- AOS Animation Link -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
      body{
        background: url(asset/images/background\ 3.jpg);
        background-attachment: fixed;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
      }
      #preloader{
        background: rgba(0, 50, 64) url('asset/images/loading.gif') no-repeat center ;
        background-size: 50%;
        height: 100vh;
        width: 100%;
        position: fixed;
        z-index: 100;
      }
    </style>
</head>
<body>
    <div id="preloader"></div>
    <!-- Logo appear with Small Screen-->
    <div class="logo5" 
        data-aos="fade-right"
        data-aos-offset="500"
        data-aos-easing="ease-in-sine">
        <img src="asset/icon/logo.png" alt="" id="logo-img">
    </div>
    <!-- Forgot Password Page-->
    <div class="container" 
     data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1500">
        <form action="forgot-password.php" method="POST" autocomplete="">
            <h2 style="color: #fff; padding-bottom:30px; text-align:center;font-size:25px">Forgot Password</h2>
                <?php
                    if(count($errors) > 0){
                ?>
                    <div class="alert alert-danger text-center" style="padding:7px;color:#a51b0b;background-color: #d4edda; margin-bottom:10px;border-radius:5px;">
                        <?php 
                            foreach($errors as $error){
                                echo $error;
                            }
                        ?>
                    </div>
                    <?php
                        }
                    ?>
            <div class="form-group">
                <input class="form-control" type="email" name="email" placeholder="Enter Your Email ?" required value="<?php echo $email ?>">
            </div>
            <div class="form-group">
                <input class="form-control button" type="submit" name="check-email" value="Continue">
            </div>
            <div class="Forgot password-login">
                <span class="text" style="color:#fff;">Did you remember your password?
                    <a href="Login.php" class="text Login-link" style="color:rgba(0, 133, 88, 0.87)">Login Now</a>
                </span>
            </div>
        </form>
    </div>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<Script src="javascript/Preloader.js"></Script>
<script>
  AOS.init();
</script>
</body>
</html>