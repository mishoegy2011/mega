<?php require_once "controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
if($email == false){
  header('Location: login.php');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MEGA IDE | Verification</title>
    <link rel="stylesheet" href="css/Login & Registration Form.css">
    <link rel="stylesheet" href="css/Forgot Password.css">
    <link rel="shortcut icon" href="asset/icon/logo.png">
    <!-- AOS Animation Link -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
      body{
        background: url(asset/images/background\ 3.jpg);
        background-attachment: fixed;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
      }
      #preloader{
        background: rgba(0, 50, 64) url('asset/images/loading.gif') no-repeat center ;
        background-size: 50%;
        height: 100vh;
        width: 100%;
        position: fixed;
        z-index: 100;
      }
    </style>
</head>
<body>
    <div id="preloader"></div>
    <!-- Logo appear with Small Screen-->
    <div class="logo5" 
        data-aos="fade-right"
        data-aos-offset="500"
        data-aos-easing="ease-in-sine">
        <img src="asset/icon/logo.png" alt="" id="logo-img">
    </div>
    <!-- User OTP Page-->
    <div class="container"
     data-aos="fade-down"
     data-aos-easing="linear"
     data-aos-duration="1500">
        <form action="user-otp.php" method="POST" autocomplete="off">
            <h2 style="color: #fff; padding-bottom:10px; text-align:center;font-size:25px">Code Verification</h2>
            <?php 
                if(isset($_SESSION['info'])){
            ?>
            <div class="alert alert-success text-center" style="text-align:center;padding:7px;color:#155724;;background-color: #d4edda; margin-bottom:10px;border-radius:5px;">
                <?php echo $_SESSION['info']; ?>
            </div>
            <?php
                }
            ?>
            <?php
                if(count($errors) > 0){
            ?>
            <div class="alert alert-danger text-center" style="text-align:center;padding:7px;color:#a51b0b;background-color: #d4edda; margin-bottom:10px;border-radius:5px;">
                <?php
                    foreach($errors as $showerror){
                        echo $showerror;
                    }
                ?>
            </div>
            <?php
                }
            ?>
            <div class="form-group">
                <input class="form-control" type="number" name="otp" placeholder="Enter Verification Code ?" required>
            </div>
            <div class="form-group">
                <input class="form-control button" type="submit" name="check" value="Submit">
            </div>
        </form>
    </div>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<Script src="javascript/Preloader.js"></Script>
<script>
  AOS.init();
</script>
</body>
</html>