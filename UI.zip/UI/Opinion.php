<?php
$servername = "localhost";
$username = "root";
$password = "";

try {
  $conn = new PDO("mysql:host=$servername;dbname=contact_us", $username, $password);
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  require_once('./Contact US.php');
  if(isset($_POST['submit'])){
    $sql = 'INSERT INTO user(name,email,number,message) VALUES(:name,:email,:password,:message)';

    $statement = $conn->prepare($sql);

    $statement->execute([
        ':name' => $_POST['name'],
        ':email' => $_POST['email'],
        ':password' => $_POST['number'],
        ':message' => $_POST['message']
    ]);
  }
} catch(PDOException $e) {
  echo "Connection failed: " . $e->getMessage();
}
?>