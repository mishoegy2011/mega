// ------------------------------------------------------------------------------------------------------
// navigator.geolocation  يستخدم لتحقق إن كان متصفح وجهاز مستخدم يدعم خاصية تحديد مواقع              
// navigator.geolocation.getCurrentPosition()يستخدم لطلب صلاحية وصول إلى موقع من المستخدم
//                                            ولحصول على معلومات متعلقة بالموقع المستخدم
// ------------------------------------------------------------------------------------------------------
// navigator.geolocation.watchPosition() يستخدم للحصول على موقع مستخدم ويتم تحديث موقع بالاستمرار                                         
// ------------------------------------------------------------------------------------------------------
// navigator.geolocation.clearWatch(id); يستخدم لإيقاف تتبع مستخدم | ايقاف عرض موقع مستخدم بشكل مباشر
// ------------------------------------------------------------------------------------------------------

function myclick(){
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var message = document.getElementById('message').value;
    if(name==="" || email==="" || message===""){
        alert("Please Enter Your Informations!");
    }
    else{
        alert("Your information has been sent to the admin.");
    }
}

var liveMap;

if(navigator.geolocation){
    liveMap = navigator.geolocation.getCurrentPosition(function(position){
        document.getElementById("map").innerHTML = `
        <iframe style="border:0;border-top-left-radius: 25px;border-bottom-left-radius: 25px;" src="https://www.openstreetmap.org/export/embed.html?bbox=${position.coords.longitude},${position.coords.latitude}&;layer=mapnik"></iframe>`        
        console.log(position)
    },
    function(error){
        console.log(error)
    }
    )};