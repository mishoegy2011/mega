const wrapper = document.querySelector(".wrapper"),
signupHeader = document.querySelector(".signup header"),
loginHeader = document.querySelector(".login header");
  
loginHeader.addEventListener("click", () => {
    wrapper.classList.add("active");
});

signupHeader.addEventListener("click", () => {
    wrapper.classList.remove("active");
});

var x = document.getElementById('pass1');
var y = document.getElementById('icon1');
var d = document.getElementById('pass3');
var c = document.getElementById('icon3');
var a = document.getElementById('pass2');
var b = document.getElementById('icon2');

y.onclick = function(){
    if(x.className == 'active1'){
    x.setAttribute('type' , 'text');
    icon1.className = "fa fa-eye";
    x.className='';}
    else{
      x.setAttribute('type' , 'password');
      icon1.className = "fa fa-eye-slash";
      x.className='active1';
    }
}

b.onclick = function(){
    if(a.className == 'active2'){
    a.setAttribute('type' , 'text');
    icon2.className = "fa fa-eye";
    a.className='';}
    else{
      a.setAttribute('type' , 'password');
      icon2.className = "fa fa-eye-slash";
      a.className='active2';
    }
}

c.onclick = function(){
  if(d.className == 'active3'){
  d.setAttribute('type' , 'text');
  icon3.className = "fa fa-eye";
  d.className='';}
  else{
    d.setAttribute('type' , 'password');
    icon3.className = "fa fa-eye-slash";
    d.className='active3';
  }
}