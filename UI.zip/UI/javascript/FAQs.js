const faqs = document.querySelectorAll('.faq');
faqs.forEach(faq =>{
    faq.addEventListener('click' , ()=>{
        faq.classList.toggle("active");
    })
})

$(document).ready(function(){
    $("#Btn").click(
	    function(){
	    $("#learn").slideDown(1000);
        });
	$("#Btn").dblclick(
	    function(){
	    $("#learn").slideUp(1000);
        });
});