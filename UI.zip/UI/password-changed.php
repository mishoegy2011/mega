<?php require_once "controllerUserData.php"; ?>
<?php
if($_SESSION['info'] == false){
    header('Location: login-user.php');  
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>MEGA IDE | Password-Changed</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/Password Changed.css">
    <link rel="shortcut icon" href="asset/icon/logo.png">
    <!-- AOS Animation Link -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <style>
      body{
        background: url(asset/images/background\ 3.jpg);
        background-attachment: fixed;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
      }
      #preloader{
        background: rgba(0, 50, 64) url('asset/images/loading.gif') no-repeat center ;
        background-size: 50%;
        height: 100vh;
        width: 100%;
        position: fixed;
        z-index: 100;
      }
    </style>
</head>
<body>
    <div id="preloader"></div>
    <!-- Logo appear with Small Screen -->
    <div class="logo5" 
        data-aos="fade-right"
        data-aos-offset="500"
        data-aos-easing="ease-in-sine">
        <img src="asset/icon/logo.png" alt="" id="logo-img">
    </div>
    <!-- Password Changed Page -->
    <div class="container">
        <div class="row"
        data-aos="fade-down"
        data-aos-easing="linear"
        data-aos-duration="1500">
            <div class="col-md-4 offset-md-4 form login-form">
            <?php 
            if(isset($_SESSION['info'])){
                ?>
                <div class="alert alert-success text-center" style="text-align:center;padding:7px;color:#155724;;background-color: #d4edda; margin-bottom:10px;border-radius:5px;">
                <?php echo $_SESSION['info']; ?>
                </div>
                <?php
            }
            ?>
                <form action="Login.php" method="POST">
                    <div class="form-group">
                        <input class="form-control button" type="submit" name="login-now" value="Login Now">
                    </div>
                </form>
            </div>
        </div>
    </div>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<Script src="javascript/Preloader.js"></Script>
<script>
  AOS.init();
</script>
</body>
</html>