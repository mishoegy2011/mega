<?php require_once "controllerUserData.php"; ?>
<?php 
$email = $_SESSION['email'];
$password = $_SESSION['password'];
if($email != false && $password != false){
    $sql = "SELECT * FROM usertable WHERE email = '$email'";
    $run_Sql = mysqli_query($con, $sql);
    if($run_Sql){
        $fetch_info = mysqli_fetch_assoc($run_Sql);
        $status = $fetch_info['status'];
        $code = $fetch_info['code'];
        if($status == "verified"){
            if($code != 0){
                header('Location: reset-code.php');
            }
        }else{
            header('Location: user-otp.php');
        }
    }
}else{
    header('Location: Login.php');
}
?>
<?php
$username = "root";
$password = "";
$database = new PDO("mysql:host=localhost; dbname=projects;",$username,$password);

$myFiles = $database->prepare("SELECT * FROM files WHERE fileType = 'text/'");
$myFiles->execute();

foreach($myFiles AS $data){
    $getFile = "data:" . $data['fileType'] . ";base64,".base64_encode($data['file']);
    echo "<a href='" . $getFile. "' download>" .$data['fileName'] . "</a> <br>";
}
$email = $_SESSION['email'];
$password = $_SESSION['password'];
if($email != false && $password != false){
    $sql = "SELECT * FROM files WHERE email = '$email'";

    if(isset($_POST['upload'])){
        $fileName = $_FILES['file']["name"];
        $fileType = $_FILES['file']["type"];
        $fileData = file_get_contents( $_FILES['file']["tmp_name"]);
        $addFile = $database->prepare("INSERT INTO files(email,file,fileName,fileType) 
            VALUES(:email,:file ,:fileName,:fileType)");
        $addFile->bindParam("email",$email);
        $addFile->bindParam("file",$fileData);
        $addFile->bindParam("fileName",$fileName);
        $addFile->bindParam("fileType",$fileType);
  
        if($addFile->execute()){
            echo 'تم حفظ ملف';
            header("Location: Java Compiler.php");
        }else{
            echo 'فشل تخزين ملف';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
    <meta name="description" content="Run Java and other popular programming languages through our website.">
    <meta name="keywords" content="Java, Java Compiler, Online Java, Java Online.">
    <meta name="author" content="MEGA IDE">
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="css/Style.css"/>
    <link rel="stylesheet" href="css/Responsive Compiler.css">
    <link rel="stylesheet" href="css/Sidebar Menu.css">
    <link rel="stylesheet" href="css/Responsive Sidebar Menu.css">
    <link rel="stylesheet" href="css/Mobile.css">
    <link rel="stylesheet" href="css/Responsive Mobile Bar.css">
    <link rel="shortcut icon" href="asset/icon/logo.png">
    <!-- Boxicons CDN Link -->
    <link href='https://unpkg.com/boxicons@2.0.7/css/boxicons.min.css' rel='stylesheet'>
    <!-- Font Awesome CDN Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.1/css/all.min.css">
    <!-- AOS Animation Link -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <title>MEGA IDE | Java Compiler</title>
    <style>
      body{
        background: url(asset/images/background\ 3.jpg);
        background-attachment: fixed;
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
      }
      #preloader{
        background: rgba(0, 50, 64) url('asset/images/loading.gif') no-repeat center ;
        background-size: 50%;
        height: 100vh;
        width: 100%;
        position: fixed;
        z-index: 100;
      }
    </style>
</head>
<body id="body">
  <div id="preloader"></div>
  <!-- Small Bar (Small Screen) -->
    <input type="checkbox" id="click" class="input10">
    <div class="navigation" data-aos="zoom-out">
    <a href="Logout.php">
      <img src="asset/icon/home.png" alt="This is Home Logo">
    </a>
    <a href="Delete Files.php">
      <img src="asset/icon/layers.png" style="width: 30px; height: 30px;margin-top: 10px;" alt="This is Projects Logo">
    </a>
    <a href="Html & Css & js Compiler.php">
        <img src="asset/icon/code.png" alt="This is Html & Css & JS Logo">
    </a>
    <a href="Java Compiler.php">
      <img src="asset/icon/java.png" alt="This is Java Logo">
    </a>
    <a href="C++ Compiler.php">
      <img src="asset/icon/c plus plus.png" alt="This is C++ Logo">
    </a>
    <a href="PHP Compiler.php">
      <img src="asset/icon/php.png" alt="This is php Logo">
    </a>
    <a href="Python Compiler.php">
      <img src="asset/icon/python.png" alt="This is Python Logo">
    </a>
    <a href="Contact US.php">
      <img src="asset/icon/send.png" alt="This is Contact Logo">
    </a>
    <a href="Logout-User.php" onclick="window.alert('Signing out');">
      <i class='bx bx-log-out' style="color: #00BFA6;font-size: 25px;margin-left: -5px;margin-top: 13px;" id="log_in"></i>
    </a>
        <label class="fas fa-plus" for="click"></label>
    </div>
  <!-- Large Bar (Large Screen) -->
<div class="sidebar">
    <div class="logo-details">
      <div class="icon">
        <img src="asset/icon/logo.png" alt="" width="80" height="60">
      </div>
      <div class="logo_name">MEGA&nbsp;IDE</div>
      <i class='bx bx-menu' id="btn" ></i>
    </div>
    <ul class="nav-list">
        <li>
            <a href="Logout.php">
              <img src="asset/icon/home.png" alt="This is Home Logo" style="margin-left: 8px;">
              <span class="links_name">Home</span>
            </a>
            <span class="tooltip">Home</span>
        </li>
        <li>
          <a href="Delete Files.php">
            <img src="asset/icon/layers.png" alt="This is Projects Logo" style="margin-left: 8px;scale: 0.8;">
            <span class="links_name">My Projects</span>
          </a>
          <span class="tooltip">My Projects</span>
        </li>
        <li>
            <a href="Html & Css & js Compiler.php">
              <img src="asset/icon/code.png" alt="This is Html & Css & JS Logo" style="margin-left: 8px;">
              <span class="links_name">Html / Css / Js Editor</span>
            </a>
            <span class="tooltip">Html / Css / Js Editor</span>
        </li>
        <li>
            <a href="Java Compiler.php">
              <img src="asset/icon/java.png" alt="This is Java Logo" style="margin-left: 8px;">
              <span class="links_name">Online Java Compiler</span>
            </a>
            <span class="tooltip">Online Java Compiler</span>
        </li>
        <li>
            <a href="C++ Compiler.php">
              <img src="asset/icon/c plus plus.png" alt="This is C++ Logo" style="margin-left: 8px;">
              <span class="links_name">Online C & C++ Compiler</span>
            </a>
            <span class="tooltip">Online C & C++ Compiler</span>
        </li>
        <li>
            <a href="PHP Compiler.php">
              <img src="asset/icon/php.png" alt="This is php Logo" style="margin-left: 8px;">
              <span class="links_name">Online PHP Compiler</span>
            </a>
            <span class="tooltip">Online PHP Compiler</span>
        </li>
        <li>
            <a href="Python Compiler.php">
              <img src="asset/icon/python.png" alt="This is Python Logo" style="margin-left: 8px;">
              <span class="links_name">Online Python Compiler</span>
            </a>
            <span class="tooltip">Online Python Compiler</span>
        </li>
        <li>
            <a href="Contact US.php">
              <img src="asset/icon/send.png" alt="This is Contact Logo" style="margin-left: 8px;">
              <span class="links_name">Contact US</span>
            </a>
            <span class="tooltip">Contact US</span>
        </li>
        <br><br><br><br>
        <li class="profile">
            <div class="profile-details">
              <i class='bx bx-user-circle' style='color:#ffffff;'></i>
                <div class="name_job">
                    <div class="name">MEGA IDE</div>
                <div class="job">Compiler Code</div>
                </div>
            </div>
               <a href="Logout-User.php" onclick="window.alert('Signing out');"><i class='bx bx-log-out' style="color: #ffffff;" id="log_in"></i></a>
        </li>
    </ul>
</div>
<!-- Java Compiler -->
<div class="controle-panel">
    Selected Language :
    <select id="languages" class="languages" onchange="changelang()">
        <option value="java">Java</option>
    </select>
</div>
<div id="editor" data-aos="zoom-in"></div>
<div class="button-container">
    <button class="btn" onclick="executeCode()">Run</button>
</div>
<div id="output"></div>
<!-- Save As -->
<div class="divs">
<div class="wrapper" data-aos="zoom-in">
    <div class="file-options">
        <div class="option file-name">
            <label>File Name</label>
            <input type="text" spellcheck="false" placeholder="Enter Your File Name ?">
        </div>
        <div class="option save-as">
            <label>Save as</label>
            <div class="select-menu">
                <select>
                    <option value="none">Choose Extension</option>
                    <option value="php">PHP File (.php)</option>
                    <option value="py">Python File (.py)</option>
                    <option value="java">Java File (.java)</option>
                    <option value="cpp">C++ File (.cpp)</option>
                </select>
            </div>
        </div>
    </div>
    <button class="save-btn" type="button">Save As </button>
    <input type="file" id="file-input"/>
</div>
<!-- Save File in Database -->
<div class="wrapper1" data-aos="zoom-in">
    <div class="file-options">
        <label style="margin:auto;"> Save The File in The Database </label>
    </div>
    <form method="POST" enctype="multipart/form-data">
        <input type="file" name="file" required id="file-input"/>
        <button type="submit" name="upload" class="save-btn">Save File</button>
    </form>
</div>
</div>
<br><br><br><br>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
<script src="JS/lib/theme-monokai.js"></script>
<script src="javascript/Sidebar Menu.js"></script>
<Script src="javascript/Preloader.js"></Script>
<script src="JS/lib/ace.js"></script>
<script src="JS/Java.js"></script>
<script>
  AOS.init();
</script>
</body>
</html>